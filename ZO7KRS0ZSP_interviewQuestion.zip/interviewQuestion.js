let m = 3;
let n = 5;

//creating the table..
let table = [];
for (let i = 0; i < m; i++) {
    let row = [];
    for (let j = 0; j < n; j++) {
        let random_number = Math.random() * 10;
        random_number = Math.ceil(random_number);
        row.push(random_number);
    }
    table.push(row);
}

//printing the table..
console.log(table);


//creating the 5 patterns..
let pattern1 = table[0];
let pattern2 = table[1];
let pattern3 = table[2];
let pattern4 = [];
pattern4.push(table[0][0], table[1][1], table[2][2], table[1][3], table[0][4]);
let pattern5 = [];
pattern5.push(table[1][0], table[1][1], table[0][2], table[1][3], table[1][4]);


//getting the desired output..
let patternNo = 1;
for (let pattern of [pattern1, pattern2, pattern3, pattern4, pattern5]) {
    for (let i of pattern) {
        let count = pattern.filter(eachItem => (eachItem === i)).length;
        if (count >= 3) {
            console.log("Number: " + i);
            console.log("Count: " + count);
            console.log("Pattern: " + patternNo);
        }
        patternNo = patternNo + 1;
        break;
    }
}